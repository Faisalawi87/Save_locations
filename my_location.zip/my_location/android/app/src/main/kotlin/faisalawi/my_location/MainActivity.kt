package faisalawi.my_location

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
